# LNIS AFS Validator

## 1. 개요

LNIS AFS Validator는 GNSS RAW 데이터를 LunaNet AFS 프레임으로 부호화하여 UDP로 전송하고, 수신 측에서 다시 RAW로 복원해 데이터 무결성과 전송 성능을 검증하는 Windows용 .NET 8 WPF 프로그램이다.

송신부는 기존 `capture.graw` 파일을 선택하거나 같은 화면의 GNSS COM 탭에서 Windows가 인식한 COM1, COM2 등의 포트를 선택해 원본 직렬 데이터를 받을 수 있다. 장비 프로토콜은 인터페이스로 분리되어 있으며, 실제 프로토콜이 결정되기 전에는 원본 `serial-input.bin`을 보존한다.

정상 송수신뿐 아니라 AFS 오류정정 실험설계의 Test A~E를 실행할 수 있다.

| 시험 | 내용 | 상태 |
|---|---|---|
| Test A | 정상 AFS/UDP 종단간 송수신과 RAW 복원 | 구현 |
| Test B | Random 심볼 오류 반복시험 | 구현 |
| Test C | Burst 연속 심볼 오류 반복시험 | 구현 |
| Test D | SP 훼손 후 다음 정상 프레임 재동기·복호 복귀 | 구현 |
| Test E | Seed 기반 의도적 UDP Frame 데이터그램 Drop | 구현 |
| 다중 PRN·PVT | PVT 성공률, 위치오차, PVT 복귀시간 | 미구현 |
| HDTN/BPv7 | DTN 라우팅과 재라우팅 | 미구현 |

현재 프로그램은 AFS 디지털 프레임과 UDP 전달 경로를 시험한다. 확산, 반송파 변조, I/Q 생성, RF 송수신, 신호 획득·추적 및 실제 PVT 계산은 수행하지 않는다.

```text
capture.graw
→ RAW 레코드 분할
→ SB3/SB4 사용자 정의 Fragment
→ CRC-24Q
→ LDPC 부호화·천공
→ 인터리빙
→ 6000심볼 AFS 프레임
→ 750바이트 MSB-first 패킹
→ UDP 송수신 또는 오류 주입
→ 디인터리빙·LDPC 복호·CRC 검사
→ RAW 재조립
→ reconstructed.graw
→ CRC32·SHA-256 비교
```

## 프로그램 전체 동작 흐름

프로그램을 실행하면 시작 화면에서 `송신부`, `수신부`, `오류정정 실험` 중 하나를 연다. GNSS COM 수집은 별도 역할이 아니라 송신부의 입력 방법 중 하나다. 송수신 시험은 수신부를 먼저 대기시킨 다음 송신부를 실행하며, 오류정정 실험은 네트워크 없이 한 PC 안에서 수행한다.

```text
LNIS AFS Validator 실행
        │
        ▼
   시작 대시보드
        │
        ├─ 수신부 ───── UDP 포트 대기 ─────────────────────────────┐
        │                                                          │
        ├─ 송신부 ─┬─ 기존 capture.graw 파일 선택                   │
        │          │                                               │
        │          └─ GNSS COM 입력 탭                             │
        │               ├─ 활성 COM 포트·Baud rate 선택             │
        │               ├─ 프로토콜 미정: serial-input.bin 보존     │
        │               └─ 등록 어댑터: capture.graw 생성·자동 적용 │
        │                  │                                       │
        │                  ▼                                       │
        │             AFS 프레임 생성                              │
        │        CRC-24Q → LDPC → 인터리빙                          │
        │                  │                                       │
        │                  ▼                                       │
        │       6000심볼을 750바이트로 패킹                         │
        │                  │                                       │
        │                  ▼                                       │
        │        UDP Broadcast 데이터그램 전송 ─────────────────────┤
        │                                                          ▼
        │                                              중복 제거·AFS 복호
        │                                       디인터리빙 → LDPC → CRC-24Q
        │                                                          │
        │                                                          ▼
        │                                                RAW Fragment 재조립
        │                                                          │
        │                                                          ▼
        │                                               reconstructed.graw 생성
        │                                                          │
        │                                                          ▼
        │                                              길이·레코드·SHA-256 비교
        │                                                          │
        │                                  결과 유니캐스트 ◀────────┘
        │                                          │
        │                                          ▼
        │                              송신부·수신부 결과 화면/파일
        │
        └─ 오류정정 실험 ── 정상 AFS 프레임 생성
                           │
                           ├─ Random 심볼 반전(Test B)
                           ├─ Burst 연속 심볼 반전(Test C)
                           └─ SP 훼손·재동기(Test D)
                                      │
                                      ▼
                          LDPC·CRC·복원/재동기 성공률 집계
                                      │
                                      ▼
                              화면 표 + JSON + CSV
```

### 송신부 GNSS COM 입력의 실제 순서

1. 송신부의 `GNSS COM에서 수집` 탭을 열고 Windows가 현재 인식한 COM 포트 목록에서 장비 포트를 선택한다.
2. 장비를 새로 연결했다면 `새로고침`으로 COM1, COM2 등의 활성 포트 목록을 다시 조회한다. 필요하면 포트 이름을 직접 입력할 수도 있다.
3. Baud rate, DTR/RTS와 저장 폴더를 설정하고, 장비 프로토콜이 아직 정해지지 않았다면 `원본 바이트 저장(프로토콜 미정)`을 선택한다.
4. 수집 서비스가 선택한 `SerialPort`를 열고 들어오는 모든 바이트를 변경 없이 `serial-input.bin`에 기록한다.
5. 선택된 `IGnssDeviceProtocolAdapter`에도 같은 바이트 조각을 전달한다. COM 읽기와 장비별 해석은 서로 의존하지 않는다.
6. 어댑터가 `ObservationEpochMessage`, `NavigationUpdateMessage` 등을 반환할 수 있을 때만 정규화 `capture.graw`를 생성한다.
7. 수집이 끝나면 생성된 `capture.graw` 경로가 같은 송신부의 AFS 입력 경로에 자동 적용된다.

현재 등록된 어댑터:

| ID | 목적 | `capture.graw` 생성 |
|---|---|---|
| `raw-only` | 아직 모르는 장비 프로토콜의 원본 직렬 바이트 보존 | 아니요 |
| `lnis-canonical-v1` | 시험 및 외부 변환기 연동용 4바이트 길이 + LGRW v1 스트림 | 예 |

특정 제조사의 UBX나 다른 바이너리 프로토콜은 아직 선택하지 않았다. 장비가 결정되면 `IGnssDeviceProtocolAdapter`를 구현하고 `GnssProtocolAdapterCatalog`에 등록한다. 기존 COM 수집 패널, 송신부 ViewModel과 AFS 송신 코드는 변경할 필요가 없다.

### 송수신 시험의 실제 순서

1. 수신 PC에서 수신부 창을 열고 데이터 포트와 결과 포트를 확인한 뒤 `수신 대기`를 누른다.
2. 송신 PC에서 송신부 창을 열고 `capture.graw`, Broadcast 주소, 포트와 중복 송신 횟수를 설정한다.
3. 송신부는 RAW 레코드를 SB3/SB4 Fragment로 나누고, 내부 검증 패턴으로 SB2를 구성한다.
4. 각 SB에 CRC-24Q와 LDPC를 적용하고 SB2~SB4를 인터리빙하여 정확히 6000심볼의 AFS 프레임을 만든다.
5. 6000개 이진 심볼을 MSB-first 750바이트로 패킹하고, AFS 프레임 하나를 UDP 데이터그램 하나의 payload로 Broadcast한다.
6. 수신부는 동일 논리 프레임의 복제본을 제거하고, 750바이트 payload를 디인터리빙·LDPC 복호·CRC 검사한다.
7. CRC를 통과한 SB3/SB4 Fragment로 원래 RAW 레코드를 조립하여 `reconstructed.graw`를 만든다.
8. 원본과 복원 파일의 길이, 레코드 수, CRC32와 SHA-256을 비교해 Pass/Fail을 결정한다.
9. 수신 결과를 송신부의 결과 포트로 유니캐스트하고 양쪽 화면과 JSON·CSV 파일에 기록한다.

Test A는 송신부 Drop Rate를 0%로 실행한다. Test E는 같은 흐름에서 Frame 데이터그램 일부만 Seed 기반으로 의도적으로 제거하여, 중복 송신과 UDP 손실이 최종 RAW 복원에 미치는 영향을 측정한다.

### 오류정정 실험의 실제 순서

1. 프로그램이 네이티브 오픈소스 코덱으로 정상 AFS 기준 프레임을 생성한다.
2. Test B는 인터리빙이 끝난 영역의 서로 다른 심볼을 지정 개수만큼 반전한다.
3. Test C는 같은 영역에서 지정 길이의 연속 심볼을 반전한다.
4. 오류 프레임을 디인터리빙하고 SB2·SB3·SB4를 각각 LDPC 복호한 뒤 CRC-24Q와 원본 비트를 비교한다.
5. 오류 개수별 LDPC 성공률, CRC 통과율과 전체 복원률을 화면과 결과 파일에 집계한다.
6. Test D는 정상·SP 손상·정상 프레임 스트림에서 손상 프레임 거부와 다음 정상 SP 재탐색·복호 성공률을 측정한다.

이 실험의 오류는 RF 샘플 잡음이 아니라 AFS 디지털 심볼의 강제 반전이다. 따라서 결과는 CRC·LDPC·인터리빙과 프레임 동기 기능의 성능을 뜻하며 RF 수신 감도, Tracking 또는 PVT 성능을 뜻하지 않는다.

## 2. 화면 구성

### 역할별 화면

프로그램 시작 시 `AfsDashboardWindow`에서 다음 독립 창을 선택한다.

- `송신부`: 기존 `capture.graw` 파일을 선택하거나 같은 화면의 GNSS COM 탭에서 RAW를 수집한 뒤, 내부 SB2 검증 패턴과 함께 AFS 프레임을 만들어 UDP Broadcast한다. Drop Rate 0%는 Test A, 0% 초과는 Test E다.
- `수신부`: 별도 입력 파일 없이 UDP를 대기하고 AFS 복호, RAW 복원, 무결성·성능 판정을 수행한다.
- `오류정정 실험`: 네트워크와 분리된 Test B/C CRC·LDPC·인터리빙 성능과 Test D 재동기를 측정한다.

AFS 6000심볼은 MSB-first 750바이트로 패킹되며 한 AFS 프레임 전체가 한 UDP 데이터그램 payload에 들어간다. 운영 UI에는 Local 역할이 없고 루프백 종단간 경로는 자동 통합시험으로 검증한다.

외부 알마낙 입력은 없다. 화면의 PRN 8은 UDP 패킷과 시험 세션에서 프레임을 구분하는 기본 논리 식별값이며, I/Q 생성이나 RF 위성 신호·PVT 계산을 뜻하지 않는다.

### 오류 실험 전용 화면

시작 화면에서 연다. 상단에 `CRC-24Q → LDPC 부호화·천공 → 인터리빙 → 오류 주입 → 디인터리빙 → LDPC 복호 → CRC·원본 비교` 단계와 각 블록 길이를 표시한다. 결과 표는 오류 심볼 수별 전체 복원률과 SB2·SB3·SB4 각각의 LDPC 성공률·CRC 통과율을 보여준다. Test E는 송신부 화면에서 설정한다.

## 3. Test A 정상 종단간 시험

### 송신기

1. `capture.graw` 레코드를 읽는다.
2. GNSS 주차·ITOW를 넣은 결정론적 1176비트 검증 패턴으로 SB2를 만든다.
3. RAW 레코드를 최대 86바이트 단위 Fragment로 나눈다.
4. SB3과 SB4에 Fragment를 배치한다.
5. 네이티브 DLL로 6000심볼 AFS 프레임을 생성한다.
6. 각 논리 프레임을 기본 3회 UDP 전송한다.
7. 수신기의 결과를 기다린다.

### 수신기

1. UDP 패킷 CRC32와 중복 여부를 검사한다.
2. 750바이트 AFS 프레임을 네이티브 DLL로 복호한다.
3. CRC-24Q가 통과한 SB3/SB4 Fragment를 재조립한다.
4. `reconstructed.graw`를 생성한다.
5. 파일 길이, 레코드 수, CRC32, SHA-256을 비교한다.
6. 결과를 송신기로 유니캐스트한다.

필수 무결성 조건:

- 원본·복원 파일 길이 일치
- RAW 레코드 수 일치
- 모든 Fragment 조립 완료
- 레코드 CRC32 일치
- 전체 파일 SHA-256 일치

## 4. Test B Random 오류

CRC·LDPC·인터리빙이 모두 끝난 정상 AFS 프레임에서 임의 심볼을 반전한다.

```text
AFS Encode
→ 인터리빙 완료
→ Random 심볼 반전
→ LDPC Decode
→ CRC-24Q 검사
→ 원본 데이터 비교
```

기본적으로 SP와 SB1을 제외한 심볼 `120~5999`에서 오류 위치를 선택한다. 오류 위치는 Seed와 반복 번호로 결정되어 같은 설정으로 재현할 수 있다.

권장 조건:

```text
오류 개수: 1, 2, 5, 10, 20, 50
조건별 반복: 100회 이상
```

측정 항목:

- SB2/SB3/SB4 LDPC 성공 여부
- CRC-24Q 성공률
- 전체 프레임 복원률
- LDPC가 변경한 비트 수

## 5. Test C Burst 오류

인터리빙 완료 프레임의 연속 심볼 구간을 반전한다. 특정 시간 구간에 집중된 잡음·간섭을 모사하고 인터리빙 효과를 확인하는 시험이다.

권장 Burst 길이:

```text
5, 10, 20, 50, 100 symbols
```

시작 위치는 Seed와 반복 번호로 재현 가능하게 결정된다.

## 6. Test D Sync Loss와 재동기

Test D는 다음 3개 프레임을 하나의 스트림으로 만든다.

```text
Frame 0: 정상
Frame 1: 68심볼 SP 일부 훼손
Frame 2: 정상
```

동기 탐색기는 수신 시작 위치를 모른다고 가정하고 한 심볼씩 이동하며 68심볼 SP를 찾는다. 프레임 경계가 바이트 중간에 있어도 탐색할 수 있다.

측정 항목:

- 손상 프레임 거부율
- 다음 SP 재탐색 성공률
- 다음 정상 프레임 Decode 복구율
- 복구 프레임 수
- AFS 논리 복구시간
- 재탐색된 스트림 비트 위치

복구시간 계산:

```text
(다음 정상 SP 위치 - 손상 프레임 시작 위치) × 2 ms
```

이 값은 AFS 심볼 기준 논리시간이다. 실제 RF Tracking 복귀시간이나 PVT 복귀시간은 아니다.

## 7. Test E UDP Packet Drop

Test E는 실제 네트워크 손실과 구분되는 의도적 Drop 시험이다.

설정 항목:

- 독립된 Sender / Receiver 역할
- 송신부 `capture.graw` 입력
- Broadcast 주소와 UDP 포트
- 중복 송신 횟수
- Drop Rate 0~100%
- Drop Seed

Frame 데이터그램만 설정 비율로 제거한다. 시험 세션 자체가 중단되지 않도록 다음 제어 패킷은 항상 전송한다.

- TimeSyncRequest / TimeSyncResponse
- SessionStart
- Probe / ProbeResponse
- SessionEnd
- Result

동일한 Seed에서는 같은 `Frame Sequence + Copy Index` 조합이 제거된다.

기록 항목:

- 설정 Drop Rate
- 실제 제거한 데이터그램 수와 비율
- 수신·중복·손상 데이터그램 수
- 논리 AFS 프레임 손실률과 전달률
- 최종 RAW 복원과 SHA-256 결과

중복 송신이 3회이면 복제본 중 하나 이상 정상 도착한 논리 프레임은 전달 성공이다.

## 8. AFS 프레임 구조

```text
동기 패턴     68심볼
SB1           52심볼
SB2         2400심볼
SB3         1740심볼
SB4         1740심볼
-------------------
합계         6000심볼
```

6000개 이진 심볼은 MSB-first로 패킹하여 750바이트가 된다. SB2~SB4의 5880심볼은 하나의 블록으로 인터리빙된다.

### SB1

- FID 0
- TOI 0~99
- `generate_BCH_AFS_SF1()` 재사용

### SB2

- CRC 입력 1176비트
- CRC-24Q 추가 후 1200비트
- LDPC·천공 후 2400심볼
- GPS Week, ITOW와 재현 가능한 내부 검증 패턴 포함

외부 알마낙은 읽지 않는다. 현재 PRN 8은 UDP 헤더와 AFS 시험 세션의 논리 스트림 식별값일 뿐이며, 특정 위성 RF 신호 생성·궤도 계산·PVT에는 사용되지 않는다.

### SB3/SB4

- 사용자 정의 타입 63
- CRC 입력 각 846비트
- CRC-24Q 추가 후 각 870비트
- LDPC·천공 후 각 1740심볼
- 한 subframe의 실제 RAW payload 최대 86바이트

## 9. 네이티브 오픈소스 통합

`LANS-AFS-SIM-main`과 `PocketSDR-AFS-main` 원본은 직접 수정하지 않는다. 프로젝트 소유 C ABI 래퍼를 `LnisAfsCodec.dll`로 빌드한다.

```text
WPF / C#
  └─ AfsNativeCodec (P/Invoke)
       └─ LnisAfsCodec.dll
            ├─ LANS-AFS-SIM 인코더
            └─ PocketSDR-AFS 디코더
```

재사용 함수:

- `generate_BCH_AFS_SF1`
- `append_CRC24`
- `encode_LDPC_AFS_SF2`
- `encode_LDPC_AFS_SF3`
- `interleave_AFS_SF234`
- `sdr_decode_LDPC_AFS_SF2`
- `sdr_decode_LDPC_AFS_SF3`

PocketSDR-AFS LDPC 반환값:

- `0 이상`: LDPC parity 검증 성공이며 값은 복호 중 변경된 비트 수
- `-1`: LDPC parity 검증 실패
- LDPC 성공 후 CRC-24Q를 별도로 검사

LDPC 구현은 전역 상태를 사용하므로 DLL 호출은 프로세스 전체에서 직렬화한다.

## 10. 결과 상태

| 상태 | 의미 |
|---|---|
| Pass | 필수 RAW 무결성과 활성 임계값을 모두 만족 |
| Fail | RAW 불일치 또는 활성 임계값 초과 |
| Measured | 값은 측정했지만 합격 임계값이 없음 |
| NotApplicable | 현재 구성에서 측정할 수 없음 |
| Inconclusive | 취소, DLL 누락 또는 시험 미완료 |

Test B/C/D는 기본적으로 성공률을 측정하는 `Measured` 시험이다.

## 11. 결과 파일

기본 결과 위치:

```text
%LocalAppData%\LnisAfsValidator\Runs
```

### Test A / Test E 수신 결과

```text
reconstructed.graw
result.json
metrics-summary.csv
metrics-timeseries.csv
```

### Test A / Test E 송신 결과

```text
result.json
metrics-summary.csv
metrics-timeseries.csv
```

### Test B / Test C

```text
fec-result.json
fec-summary.csv
fec-trials.csv
reference-sb2.bits
reference-sb3.bits
reference-sb4.bits
실험데이터_파일설명.txt
frames/
  Random-0001/ 또는 Burst-0005/
    trial-0001-reference.afs
    trial-0001-injected.afs
    trial-0001-flipped-symbols.txt
    trial-0001-decoded-sb2.bits
    trial-0001-decoded-sb3.bits
    trial-0001-decoded-sb4.bits
```

- `reference.afs`: 오류 주입 전 정상 750바이트 프레임
- `injected.afs`: 실제 복호기에 입력한 오류 포함 프레임
- `flipped-symbols.txt`: 반전한 0 기준 심볼 인덱스
- `decoded-sb*.bits`: 복호기가 출력한 unpacked 0/1 배열

### Test D

```text
sync-result.json
sync-summary.csv
sync-trials.csv
실험데이터_파일설명.txt
SyncLoss-20/
  trial-0001-3frames.afsstream
  trial-0001-damaged-reference.afs
  trial-0001-damaged.afs
  trial-0001-flipped-sync-symbols.txt
  trial-0001-recovered.afs
```

`3frames.afsstream`은 정상·손상·정상 프레임을 연결한 2250바이트 파일이다.

## 12. 성능지표

네트워크:

- 링크 가용률
- 평균·최대 단방향 지연
- RAW goodput
- 의도적 UDP Drop Rate

전달:

- 논리 AFS 프레임 손실률
- 논리 AFS 프레임 전달률
- 중복·손상 데이터그램

오류정정:

- 오류 유형과 심볼 수
- LDPC 성공률
- CRC-24Q 성공률
- 전체 프레임 복원률
- LDPC 평균 변경 비트 수

재동기:

- 손상 프레임 거부율
- Sync 복구율
- Decode 복구율
- 평균 논리 복구시간

시스템:

- 평균·최대 CPU 사용률
- 평균·최대 메모리 사용량
- 로그 저장률

HDTN 재라우팅과 PVT 지표는 현재 `NotApplicable`이다.

## 13. UDP 프로토콜

기본값:

| 항목 | 기본값 |
|---|---:|
| 데이터 포트 | 45821 |
| 결과 포트 | 45822 |
| Frame 중복 송신 | 3회 |
| 결과 대기 | 30초 |
| SessionEnd 유예 | 1000ms |
| Probe 간격 | 1000ms |

지원 패킷:

- `TimeSyncRequest`, `TimeSyncResponse`
- `SessionStart`
- `Frame`
- `Probe`, `ProbeResponse`
- `SessionEnd`
- `Result`

모든 패킷은 `LAFS` magic, 버전, TestId, 종류, Sequence, CopyIndex, PRN, WN/ITOW/TOI, 송신시각, payload 길이와 CRC32를 포함한다.

동일 논리 패킷은 `TestId + PacketKind + Sequence`로 중복 제거한다. NACK 기반 재전송은 사용하지 않는다.

시험 시작 전 4-timestamp 교환을 8회 수행하고 중앙값으로 송·수신 PC의 시계 오프셋을 추정한다.

## 14. 빌드

요구사항:

- Windows x64
- .NET 8 SDK
- DLL 재빌드 시 WSL Ubuntu
- WSL의 `x86_64-w64-mingw32-gcc`

솔루션 루트에서 실행한다.

```powershell
dotnet build LnisAfsValidator.sln -c Debug -p:Platform=x64
```

출력:

```text
bin/Debug/net8.0-windows/LnisAfsValidator.exe
bin/Debug/net8.0-windows/LnisAfsCodec.dll
```

네이티브 DLL 재빌드:

```powershell
./Native/LnisAfsCodec/build-wsl.ps1
```

출력:

```text
Native/LnisAfsCodec/bin/win-x64/LnisAfsCodec.dll
```

O: 보안 디스크를 WSL에서 직접 마운트할 수 없는 환경을 위해 스크립트가 필요한 파일을 Windows 임시 폴더에 staging한다. 오픈소스 원본은 변경하지 않는다.

## 15. 테스트

```powershell
dotnet test Tests/LnisAfsValidator.Tests.csproj
```

자동검증 항목:

- GNSS RAW 직렬화 왕복
- 분할된 COM 바이트 스트림의 원본 무손실 저장
- 프로토콜 미정 모드와 Canonical 어댑터의 `capture.graw` 생성 조건
- RAW Fragment 분할·재조립·CRC32
- UDP packet encode/decode와 손상 검출
- 논리 프레임 손실률·전달률·지연
- 실제 네이티브 DLL AFS encode/decode
- 로컬 UDP 종단간 RAW 복원
- Random/Burst/SyncLoss 오류 위치
- 오류 개수 입력 파서
- 오류시험 바이너리·CSV·JSON 생성
- 비트 단위 SP 재탐색
- 다음 정상 프레임 Decode 복구
- Seed 기반 UDP Drop 재현성

현재 레거시 WSL/IQ 전용 테스트를 제거한 뒤 전체 자동 테스트는 28개이며 모두 통과한다. 네이티브 DLL이 없으면 코덱 통합시험은 건너뛰지 않고 실패한다.

실제 WPF 프로세스를 송신부와 수신부로 각각 실행한 인수시험에서도 임시 GNSS RAW 파일의 길이와 SHA-256이 복원 파일과 일치했다. Test E는 3회 중복 송신에서 계획된 데이터그램 1개를 제거하고도 복원에 성공했으며, Random/Burst/SyncLoss 화면 시험 결과도 JSON·CSV로 생성됨을 확인했다.

### 반복 가능한 화면 실행 인수

```powershell
# 수신부를 먼저 실행
LnisAfsValidator.exe --receiver --auto-start --data-port=45821 --result-port=45822

# 송신부 정상 전송(Test A)
LnisAfsValidator.exe --sender --auto-start --capture=C:\data\capture.graw --broadcast=255.255.255.255

# 송신부 의도적 Drop(Test E)
LnisAfsValidator.exe --sender --auto-start --capture=C:\data\capture.graw --drop-rate=10 --drop-seed=2

# 로컬 오류정정 시험(Test B 예시)
LnisAfsValidator.exe --experiment --auto-start --mode=Random --errors=1,5,20 --trials=100 --seed=2025
```

## 16. 주요 코드

```text
AfsDashboardWindow.xaml
  송신부·수신부·오류정정 실험 시작 화면

AfsDashboardViewModel.cs
  역할별 독립 창 실행

Presentation/Sender/
  Test A/E 송신 XAML과 ViewModel

Presentation/Receiver/
  AFS 수신·RAW 복원 XAML과 ViewModel

Presentation/Gnss/
  송신부에 삽입되는 COM 포트 설정·수집 현황 패널과 하위 ViewModel

Core/Gnss/GnssCaptureAbstractions.cs
  바이트 소스·프로토콜 어댑터·캡처 서비스 인터페이스

Infrastructure/Gnss/Sources/SerialPortGnssByteSource.cs
  제조사 중립 SerialPort 입력

Infrastructure/Gnss/Protocols/GnssProtocolAdapters.cs
  Raw-only·Canonical 어댑터와 확장 카탈로그

Infrastructure/Gnss/Capture/GnssComCaptureService.cs
  원본 Serial 보존과 선택적 capture.graw 기록

AfsErrorExperimentWindow.xaml
  코덱 처리 사슬과 Test B/C/D 결과 표

AfsErrorExperimentViewModel.cs
  오류정정·재동기 로컬 반복시험 제어

Core/Afs/ErrorCorrection/AfsErrorInjectionModels.cs
  오류 주입 설정과 결과

Core/Afs/ErrorCorrection/AfsErrorCorrectionExperimentModels.cs
  Test B/C 결과 모델

Core/Afs/Recovery/AfsSyncRecoveryModels.cs
  Test D 결과 모델

Infrastructure/Afs/Experiments/AfsErrorInjector.cs
  Random·Burst·SyncLoss 심볼 반전

Infrastructure/Afs/Experiments/AfsErrorCorrectionExperimentService.cs
  Test B/C 반복 실행·집계·파일 저장

Infrastructure/Afs/Synchronization/AfsFrameSynchronizer.cs
  68심볼 SP 탐색과 프레임 추출

Infrastructure/Afs/Synchronization/AfsSyncRecoveryExperimentService.cs
  Test D 3프레임 생성·재탐색·복구시간

Infrastructure/Afs/Experiments/AfsPacketDropSimulator.cs
  Test E Seed 기반 데이터그램 제거 결정

Infrastructure/Afs/Transport/AfsUdpSessionService.cs
  정상 UDP 송수신과 Test E Frame Drop

Infrastructure/Afs/Codecs/AfsNativeCodec.cs
  DLL P/Invoke와 LDPC 상태 전달

Native/LnisAfsCodec/
  프로젝트 소유 C ABI 래퍼와 빌드 스크립트
```

## 17. 제한사항

- 실제 GNSS 장비 프로토콜은 아직 결정되지 않아 제조사별 어댑터가 없다. 현재 실제 COM 장비는 원본 바이트 보존까지 보장한다.
- `capture.graw` 생성에는 해당 장비 프로토콜을 해석하는 `IGnssDeviceProtocolAdapter` 구현이 필요하다.
- PRN 8 단일 논리 AFS 스트림만 지원한다.
- 수신기는 한 대만 지원한다.
- Test D 복구시간은 2ms/symbol을 적용한 논리시간이다.
- RF 획득·Tracking 복귀시간은 측정하지 않는다.
- PVT Solver가 없어 PVT 성공률과 위치·시간 오차를 측정하지 않는다.
- HDTN/BPv7 라우팅과 재라우팅은 구현하지 않았다.
- UDP NACK와 선택 재전송은 구현하지 않았다.
- UDP timestamp 기반 시계 보정은 비대칭 네트워크에서 오차가 발생할 수 있다.

## 18. 라이선스

`오픈소스` 아래 LANS-AFS-SIM, PocketSDR-AFS, PocketSDR, HDTN 트리는 읽기 전용 빌드 입력과 분석 자료로 취급한다. 프로젝트 기능을 위해 원본 파일을 직접 수정하지 않는다.

배포 출력의 `licenses` 폴더에는 사용한 오픈소스 라이선스와 제3자 고지를 포함한다.
